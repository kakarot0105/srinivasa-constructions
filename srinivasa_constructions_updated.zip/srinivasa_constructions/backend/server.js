const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json());

// In‑memory store for projects and tasks
const projects = {};

/*
 * Routes
 *
 * These simple endpoints are meant to demonstrate how a REST API could be
 * designed to support the website and mobile application.  They use an
 * in‑memory object for storage; in production this should be replaced with a
 * database and proper authentication.
 */

// Create a new project
app.post('/api/projects', (req, res) => {
  const { name, description } = req.body;
  const id = uuidv4();
  projects[id] = {
    id,
    name,
    description,
    createdAt: new Date().toISOString(),
    tasks: []
  };
  return res.status(201).json(projects[id]);
});

// List all projects
app.get('/api/projects', (req, res) => {
  return res.json(Object.values(projects));
});

// Add a task to a project
app.post('/api/projects/:projectId/tasks', (req, res) => {
  const { projectId } = req.params;
  const { title, status = 'pending', description } = req.body;
  const project = projects[projectId];
  if (!project) {
    return res.status(404).json({ message: 'Project not found' });
  }
  const task = {
    id: uuidv4(),
    title,
    description,
    status,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  project.tasks.push(task);
  return res.status(201).json(task);
});

// Update task status
app.patch('/api/projects/:projectId/tasks/:taskId', (req, res) => {
  const { projectId, taskId } = req.params;
  const { status, description } = req.body;
  const project = projects[projectId];
  if (!project) {
    return res.status(404).json({ message: 'Project not found' });
  }
  const task = project.tasks.find((t) => t.id === taskId);
  if (!task) {
    return res.status(404).json({ message: 'Task not found' });
  }
  if (status) task.status = status;
  if (description) task.description = description;
  task.updatedAt = new Date().toISOString();
  return res.json(task);
});

// Get project details including tasks
app.get('/api/projects/:projectId', (req, res) => {
  const { projectId } = req.params;
  const project = projects[projectId];
  if (!project) {
    return res.status(404).json({ message: 'Project not found' });
  }
  return res.json(project);
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});